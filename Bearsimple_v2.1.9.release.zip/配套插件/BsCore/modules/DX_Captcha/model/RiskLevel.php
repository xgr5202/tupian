<?php
/**
 * Created by PhpStorm.
 * User: dingxiang-inc
 * Date: 2017/8/19
 * Time: 下午1:06
 */

class RiskLevel
{
    const ACCEPT = 'ACCEPT';
    const REVIEW = 'REVIEW';
    const REJECT = 'REJECT';
}