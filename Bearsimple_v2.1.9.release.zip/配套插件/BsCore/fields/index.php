<?php // Silence is golden.
